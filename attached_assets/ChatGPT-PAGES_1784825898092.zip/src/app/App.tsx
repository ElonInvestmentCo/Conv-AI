import { useState, useRef, useEffect } from "react";
import {
  Plus,
  Search,
  MessageSquare,
  Settings,
  ChevronDown,
  Send,
  Paperclip,
  Mic,
  Globe,
  MoreHorizontal,
  Edit3,
  Trash2,
  Share2,
  Copy,
  ThumbsUp,
  ThumbsDown,
  RefreshCw,
  X,
  Check,
  ChevronRight,
  Moon,
  Sun,
  LogOut,
  User,
  Shield,
  CreditCard,
  Bell,
  Palette,
  Zap,
  BookOpen,
  Sparkles,
  PenLine,
  Code2,
  ImageIcon,
  BrainCircuit,
  Cpu,
  Menu,
  ArrowUp,
  StopCircle,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
};

type Conversation = {
  id: string;
  title: string;
  preview: string;
  timestamp: Date;
  messages: Message[];
};

type View = "chat" | "settings" | "explore";
type SettingsTab = "general" | "account" | "security" | "data" | "billing";

// ─── Data ────────────────────────────────────────────────────────────────────

const MODELS = [
  { id: "gpt-4o", label: "GPT-4o", badge: null },
  { id: "gpt-4o-mini", label: "GPT-4o mini", badge: null },
  { id: "gpt-4", label: "GPT-4", badge: "Legacy" },
  { id: "o1", label: "o1", badge: "New" },
  { id: "o1-mini", label: "o1 mini", badge: null },
];

const SAMPLE_CONVERSATIONS: Conversation[] = [
  {
    id: "c1",
    title: "React performance optimization tips",
    preview: "How can I optimize my React app?",
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
    messages: [
      {
        id: "m1",
        role: "user",
        content: "How can I optimize my React app for better performance?",
        timestamp: new Date(Date.now() - 1000 * 60 * 31),
      },
      {
        id: "m2",
        role: "assistant",
        content: `Here are the most impactful React performance optimizations:

**1. Memoization**
Use \`React.memo\`, \`useMemo\`, and \`useCallback\` to prevent unnecessary re-renders. Only memoize when you have a measured performance problem — premature optimization adds complexity.

**2. Code Splitting**
Leverage \`React.lazy\` and \`Suspense\` to split your bundle. Load heavy components only when needed:

\`\`\`jsx
const HeavyChart = React.lazy(() => import('./HeavyChart'));
\`\`\`

**3. Virtualization**
For long lists, use \`react-window\` or \`react-virtual\` to render only visible items instead of thousands of DOM nodes.

**4. State colocation**
Keep state as close to where it's used as possible. Lifting state too high causes wide subtree re-renders.

**5. Avoid inline functions in JSX**
Define handlers outside render or with \`useCallback\` to preserve referential equality.

Would you like me to go deeper on any of these?`,
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
      },
    ],
  },
  {
    id: "c2",
    title: "Python script for data analysis",
    preview: "Write a Python script to analyze CSV data",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
    messages: [
      {
        id: "m3",
        role: "user",
        content: "Write a Python script to analyze CSV data and generate a summary report.",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
      },
      {
        id: "m4",
        role: "assistant",
        content: `Here's a comprehensive CSV analysis script using pandas:

\`\`\`python
import pandas as pd
import numpy as np
from pathlib import Path

def analyze_csv(filepath: str) -> dict:
    df = pd.read_csv(filepath)

    report = {
        "shape": df.shape,
        "columns": df.columns.tolist(),
        "dtypes": df.dtypes.to_dict(),
        "missing": df.isnull().sum().to_dict(),
        "numeric_summary": df.describe().to_dict(),
    }

    return report

if __name__ == "__main__":
    report = analyze_csv("data.csv")
    print(f"Rows: {report['shape'][0]}, Columns: {report['shape'][1]}")
\`\`\`

This handles missing values, type inference, and numeric statistics automatically.`,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
      },
    ],
  },
  {
    id: "c3",
    title: "Marketing email for product launch",
    preview: "Draft a marketing email for our new SaaS product",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    messages: [],
  },
  {
    id: "c4",
    title: "Explain quantum entanglement",
    preview: "What is quantum entanglement in simple terms?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
    messages: [],
  },
  {
    id: "c5",
    title: "SQL query optimization",
    preview: "My database queries are slow, how do I fix them?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
    messages: [],
  },
  {
    id: "c6",
    title: "Travel itinerary for Japan",
    preview: "Plan a 2-week trip to Japan for first-timers",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
    messages: [],
  },
];

const SUGGESTIONS = [
  { icon: PenLine, label: "Write", text: "a short poem about the ocean at dawn" },
  { icon: Code2, label: "Code", text: "a REST API endpoint in Express.js" },
  { icon: ImageIcon, label: "Create", text: "a product description for wireless headphones" },
  { icon: BookOpen, label: "Summarize", text: "the key ideas from Atomic Habits" },
];

const GPT_STORE_ITEMS = [
  { icon: "🎨", name: "DALL-E", desc: "Generate images from text prompts", category: "Image" },
  { icon: "📊", name: "Data Analyst", desc: "Analyze and visualize complex datasets", category: "Data" },
  { icon: "✍️", name: "Write For Me", desc: "Draft, edit, and refine your writing", category: "Writing" },
  { icon: "🌐", name: "WebPilot", desc: "Browse and interact with live websites", category: "Web" },
  { icon: "📚", name: "Scholar AI", desc: "Access peer-reviewed papers and studies", category: "Research" },
  { icon: "🧑‍💻", name: "Code Copilot", desc: "AI pair-programmer for any language", category: "Coding" },
  { icon: "🎵", name: "Music Teacher", desc: "Learn music theory and composition", category: "Education" },
  { icon: "💼", name: "Resume AI", desc: "Build and tailor your resume with AI", category: "Career" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function groupConversations(convos: Conversation[]) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 86400000);
  const sevenDaysAgo = new Date(today.getTime() - 7 * 86400000);

  const groups: { label: string; items: Conversation[] }[] = [
    { label: "Today", items: [] },
    { label: "Yesterday", items: [] },
    { label: "Previous 7 Days", items: [] },
    { label: "Older", items: [] },
  ];

  convos.forEach((c) => {
    const d = new Date(c.timestamp.getFullYear(), c.timestamp.getMonth(), c.timestamp.getDate());
    if (d >= today) groups[0].items.push(c);
    else if (d >= yesterday) groups[1].items.push(c);
    else if (d >= sevenDaysAgo) groups[2].items.push(c);
    else groups[3].items.push(c);
  });

  return groups.filter((g) => g.items.length > 0);
}

function renderMessageContent(content: string) {
  const lines = content.split("\n");
  let inCode = false;
  let codeLines: string[] = [];
  let codeLang = "";
  const result: React.ReactNode[] = [];
  let key = 0;

  const flush = () => {
    if (codeLines.length > 0) {
      result.push(
        <div key={key++} className="my-3 rounded-xl overflow-hidden border border-white/10">
          <div className="flex items-center justify-between px-4 py-2 bg-[#1a1a1a] border-b border-white/10">
            <span className="text-xs text-[#8e8ea0] font-mono">{codeLang || "code"}</span>
            <button className="flex items-center gap-1.5 text-xs text-[#8e8ea0] hover:text-white transition-colors">
              <Copy size={13} /> Copy code
            </button>
          </div>
          <pre className="bg-[#0d0d0d] p-4 overflow-x-auto text-sm font-mono text-[#e5e7eb] leading-relaxed">
            <code>{codeLines.join("\n")}</code>
          </pre>
        </div>
      );
      codeLines = [];
      codeLang = "";
    }
  };

  for (const line of lines) {
    if (line.startsWith("```")) {
      if (!inCode) {
        inCode = true;
        codeLang = line.slice(3).trim();
      } else {
        inCode = false;
        flush();
      }
      continue;
    }
    if (inCode) {
      codeLines.push(line);
      continue;
    }

    if (line.startsWith("**") && line.endsWith("**") && line.length > 4) {
      result.push(
        <p key={key++} className="font-semibold text-[#ececec] mt-4 mb-1">
          {line.slice(2, -2)}
        </p>
      );
    } else if (line.startsWith("**")) {
      const processed = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
        .replace(/`(.+?)`/g, '<code class="bg-white/10 rounded px-1.5 py-0.5 text-sm font-mono text-emerald-300">$1</code>');
      result.push(
        <p key={key++} className="leading-7 text-[#d1d5db]" dangerouslySetInnerHTML={{ __html: processed }} />
      );
    } else if (line === "") {
      result.push(<div key={key++} className="h-1" />);
    } else {
      const processed = line
        .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
        .replace(/`(.+?)`/g, '<code class="bg-white/10 rounded px-1.5 py-0.5 text-sm font-mono text-emerald-300">$1</code>');
      result.push(
        <p key={key++} className="leading-7 text-[#d1d5db]" dangerouslySetInnerHTML={{ __html: processed }} />
      );
    }
  }
  flush();
  return result;
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function ModelSelector({ model, onChange }: { model: string; onChange: (m: string) => void }) {
  const [open, setOpen] = useState(false);
  const current = MODELS.find((m) => m.id === model) ?? MODELS[0];

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-white/8 transition-colors text-[#ececec] font-semibold text-base"
      >
        {current.label}
        <ChevronDown size={16} className={`text-[#8e8ea0] transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-72 bg-[#2f2f2f] border border-white/10 rounded-xl shadow-2xl z-50 py-1 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-white/8">
              <p className="text-xs text-[#8e8ea0] font-medium uppercase tracking-wider">Model</p>
            </div>
            {MODELS.map((m) => (
              <button
                key={m.id}
                onClick={() => { onChange(m.id); setOpen(false); }}
                className={`w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition-colors text-left ${model === m.id ? "bg-white/5" : ""}`}
              >
                <div className="flex items-center gap-3">
                  {model === m.id ? (
                    <Check size={16} className="text-[#10a37f]" />
                  ) : (
                    <div className="w-4" />
                  )}
                  <span className="text-[#ececec] text-sm font-medium">{m.label}</span>
                </div>
                {m.badge && (
                  <span className="text-xs bg-[#10a37f]/20 text-[#10a37f] px-2 py-0.5 rounded-full font-medium">
                    {m.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function Sidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onSettings,
  onExplore,
  collapsed,
  onToggle,
}: {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onSettings: () => void;
  onExplore: () => void;
  collapsed: boolean;
  onToggle: () => void;
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const groups = groupConversations(conversations);

  const filtered = searchQuery
    ? conversations.filter(
        (c) =>
          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.preview.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : null;

  return (
    <aside
      className={`flex flex-col h-full bg-[#171717] transition-all duration-300 ${collapsed ? "w-0 overflow-hidden" : "w-[260px]"} flex-shrink-0`}
    >
      {/* Top actions */}
      <div className="flex items-center justify-between px-3 pt-3 pb-1">
        <button
          onClick={onToggle}
          className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors"
          title="Close sidebar"
        >
          <Menu size={18} />
        </button>
        <button
          onClick={onNew}
          className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors"
          title="New chat"
        >
          <Edit3 size={18} />
        </button>
      </div>

      {/* ChatGPT label */}
      <div
        onClick={onNew}
        className="flex items-center gap-2.5 px-4 py-2.5 mx-2 rounded-lg hover:bg-white/6 cursor-pointer transition-colors group"
      >
        <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 41 41" fill="none">
            <path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.313-2.635 10.079 10.079 0 0 0-9.614 6.977 9.967 9.967 0 0 0-6.664 4.834 10.08 10.08 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.313 2.634 10.079 10.079 0 0 0 9.614-6.976 9.967 9.967 0 0 0 6.664-4.834 10.079 10.079 0 0 0-1.24-11.818zM22.498 37.886a7.474 7.474 0 0 1-4.799-1.735c.061-.033.168-.091.237-.134l7.964-4.6a1.294 1.294 0 0 0 .655-1.134V19.054l3.366 1.944a.12.12 0 0 1 .066.092v9.299a7.505 7.505 0 0 1-7.49 7.496zM6.392 31.006a7.471 7.471 0 0 1-.894-5.023c.06.036.162.099.237.141l7.964 4.6a1.297 1.297 0 0 0 1.308 0l9.724-5.614v3.888a.12.12 0 0 1-.048.103l-8.051 4.649a7.504 7.504 0 0 1-10.24-2.744zM4.297 13.62A7.469 7.469 0 0 1 8.2 10.333c0 .068-.004.19-.004.274v9.201a1.294 1.294 0 0 0 .654 1.132l9.723 5.614-3.366 1.944a.12.12 0 0 1-.114.012L7.044 23.86a7.504 7.504 0 0 1-2.747-10.24zm27.658 6.437l-9.724-5.615 3.367-1.943a.121.121 0 0 1 .114-.012l8.048 4.648a7.498 7.498 0 0 1-1.158 13.528v-9.476a1.293 1.293 0 0 0-.647-1.13zm3.35-5.043c-.059-.037-.162-.099-.236-.141l-7.965-4.6a1.298 1.298 0 0 0-1.308 0l-9.723 5.614v-3.888a.12.12 0 0 1 .048-.103l8.05-4.645a7.497 7.497 0 0 1 11.135 7.763zm-21.063 6.929l-3.367-1.944a.12.12 0 0 1-.065-.092v-9.299a7.497 7.497 0 0 1 12.293-5.756 6.94 6.94 0 0 0-.236.134l-7.965 4.6a1.294 1.294 0 0 0-.654 1.132l-.006 11.225zm1.829-3.943l4.33-2.501 4.332 2.5v4.999l-4.331 2.5-4.331-2.5V18z" fill="currentColor" />
          </svg>
        </div>
        <span className="text-[#ececec] text-sm font-semibold">ChatGPT</span>
      </div>

      {/* Explore GPTs */}
      <button
        onClick={onExplore}
        className="flex items-center gap-2.5 px-4 py-2 mx-2 rounded-lg hover:bg-white/6 cursor-pointer transition-colors text-left"
      >
        <div className="w-6 h-6 rounded-full bg-[#2f2f2f] border border-white/10 flex items-center justify-center flex-shrink-0">
          <Sparkles size={13} className="text-[#8e8ea0]" />
        </div>
        <span className="text-[#ececec] text-sm">Explore GPTs</span>
      </button>

      {/* Search */}
      <div className="px-3 pt-2 pb-1">
        <div className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg border border-white/8">
          <Search size={14} className="text-[#8e8ea0] flex-shrink-0" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversations"
            className="bg-transparent text-sm text-[#ececec] placeholder-[#8e8ea0] outline-none w-full"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} className="text-[#8e8ea0] hover:text-white">
              <X size={13} />
            </button>
          )}
        </div>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto scrollbar-hide px-2 py-1">
        {filtered ? (
          <div>
            {filtered.length === 0 ? (
              <p className="text-center text-[#8e8ea0] text-sm py-8">No conversations found</p>
            ) : (
              filtered.map((c) => (
                <ConvoItem
                  key={c.id}
                  convo={c}
                  active={activeId === c.id}
                  hovered={hoveredId === c.id}
                  onHover={setHoveredId}
                  onClick={() => onSelect(c.id)}
                />
              ))
            )}
          </div>
        ) : (
          groups.map((g) => (
            <div key={g.label} className="mb-2">
              <p className="text-xs text-[#8e8ea0] font-medium px-3 py-1.5 uppercase tracking-wider">{g.label}</p>
              {g.items.map((c) => (
                <ConvoItem
                  key={c.id}
                  convo={c}
                  active={activeId === c.id}
                  hovered={hoveredId === c.id}
                  onHover={setHoveredId}
                  onClick={() => onSelect(c.id)}
                />
              ))}
            </div>
          ))
        )}
      </div>

      {/* Bottom user */}
      <div className="border-t border-white/8 p-2">
        <button
          onClick={onSettings}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-white/6 transition-colors text-left"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#10a37f] to-[#0d8f6e] flex items-center justify-center flex-shrink-0 text-white text-sm font-semibold">
            A
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-[#ececec] font-medium truncate">Alex Johnson</p>
            <p className="text-xs text-[#8e8ea0] truncate">Free plan</p>
          </div>
          <MoreHorizontal size={16} className="text-[#8e8ea0] flex-shrink-0" />
        </button>
      </div>
    </aside>
  );
}

function ConvoItem({
  convo,
  active,
  hovered,
  onHover,
  onClick,
}: {
  convo: Conversation;
  active: boolean;
  hovered: boolean;
  onHover: (id: string | null) => void;
  onClick: () => void;
}) {
  return (
    <div
      onMouseEnter={() => onHover(convo.id)}
      onMouseLeave={() => onHover(null)}
      onClick={onClick}
      className={`relative group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
        active ? "bg-white/10" : "hover:bg-white/6"
      }`}
    >
      <span className="text-sm text-[#ececec] truncate flex-1 leading-snug">{convo.title}</span>
      {(hovered || active) && (
        <div className="flex items-center gap-0.5 flex-shrink-0">
          <button
            onClick={(e) => e.stopPropagation()}
            className="p-1 rounded hover:bg-white/10 text-[#8e8ea0] hover:text-white transition-colors"
          >
            <Share2 size={13} />
          </button>
          <button
            onClick={(e) => e.stopPropagation()}
            className="p-1 rounded hover:bg-white/10 text-[#8e8ea0] hover:text-white transition-colors"
          >
            <Trash2 size={13} />
          </button>
        </div>
      )}
    </div>
  );
}

function ChatInput({
  onSend,
  disabled,
}: {
  onSend: (text: string) => void;
  disabled?: boolean;
}) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + "px";
    }
  }, [value]);

  const handleSend = () => {
    if (!value.trim() || disabled) return;
    onSend(value.trim());
    setValue("");
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      <div className="relative bg-[#2f2f2f] rounded-2xl border border-white/10 shadow-lg transition-all focus-within:border-white/20">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Message ChatGPT"
          rows={1}
          className="w-full bg-transparent text-[#ececec] placeholder-[#8e8ea0] resize-none outline-none px-4 pt-4 pb-2 text-base leading-relaxed max-h-[200px] overflow-y-auto"
          style={{ scrollbarWidth: "none" }}
        />
        <div className="flex items-center justify-between px-3 pb-3 pt-1">
          <div className="flex items-center gap-1">
            <button className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors" title="Attach file">
              <Paperclip size={18} />
            </button>
            <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors text-sm">
              <Globe size={15} />
              <span>Search</span>
            </button>
            <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors text-sm">
              <Zap size={15} />
              <span>Reason</span>
            </button>
          </div>
          <button
            onClick={handleSend}
            disabled={!value.trim() || disabled}
            className={`p-2 rounded-lg transition-all ${
              value.trim() && !disabled
                ? "bg-white text-black hover:bg-gray-100"
                : "bg-white/10 text-[#8e8ea0] cursor-not-allowed"
            }`}
          >
            {disabled ? <StopCircle size={18} /> : <ArrowUp size={18} />}
          </button>
        </div>
      </div>
      <p className="text-center text-xs text-[#8e8ea0] mt-3">
        ChatGPT can make mistakes. Consider checking important information.
      </p>
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const [liked, setLiked] = useState<boolean | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (message.role === "user") {
    return (
      <div className="flex justify-end group mb-6">
        <div className="max-w-[85%] md:max-w-[70%]">
          <div className="bg-[#2f2f2f] text-[#ececec] rounded-3xl px-5 py-3.5 text-base leading-relaxed">
            {message.content}
          </div>
          <div className="flex justify-end gap-1 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={handleCopy} className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors">
              {copied ? <Check size={14} className="text-[#10a37f]" /> : <Copy size={14} />}
            </button>
            <button className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors">
              <Edit3 size={14} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3 mb-6 group">
      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 mt-0.5">
        <svg width="18" height="18" viewBox="0 0 41 41" fill="none">
          <path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.313-2.635 10.079 10.079 0 0 0-9.614 6.977 9.967 9.967 0 0 0-6.664 4.834 10.08 10.08 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.313 2.634 10.079 10.079 0 0 0 9.614-6.976 9.967 9.967 0 0 0 6.664-4.834 10.079 10.079 0 0 0-1.24-11.818zM22.498 37.886a7.474 7.474 0 0 1-4.799-1.735c.061-.033.168-.091.237-.134l7.964-4.6a1.294 1.294 0 0 0 .655-1.134V19.054l3.366 1.944a.12.12 0 0 1 .066.092v9.299a7.505 7.505 0 0 1-7.49 7.496zM6.392 31.006a7.471 7.471 0 0 1-.894-5.023c.06.036.162.099.237.141l7.964 4.6a1.297 1.297 0 0 0 1.308 0l9.724-5.614v3.888a.12.12 0 0 1-.048.103l-8.051 4.649a7.504 7.504 0 0 1-10.24-2.744zM4.297 13.62A7.469 7.469 0 0 1 8.2 10.333c0 .068-.004.19-.004.274v9.201a1.294 1.294 0 0 0 .654 1.132l9.723 5.614-3.366 1.944a.12.12 0 0 1-.114.012L7.044 23.86a7.504 7.504 0 0 1-2.747-10.24zm27.658 6.437l-9.724-5.615 3.367-1.943a.121.121 0 0 1 .114-.012l8.048 4.648a7.498 7.498 0 0 1-1.158 13.528v-9.476a1.293 1.293 0 0 0-.647-1.13zm3.35-5.043c-.059-.037-.162-.099-.236-.141l-7.965-4.6a1.298 1.298 0 0 0-1.308 0l-9.723 5.614v-3.888a.12.12 0 0 1 .048-.103l8.05-4.645a7.497 7.497 0 0 1 11.135 7.763zm-21.063 6.929l-3.367-1.944a.12.12 0 0 1-.065-.092v-9.299a7.497 7.497 0 0 1 12.293-5.756 6.94 6.94 0 0 0-.236.134l-7.965 4.6a1.294 1.294 0 0 0-.654 1.132l-.006 11.225zm1.829-3.943l4.33-2.501 4.332 2.5v4.999l-4.331 2.5-4.331-2.5V18z" fill="#000" />
        </svg>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-base text-[#ececec] leading-relaxed">
          {renderMessageContent(message.content)}
        </div>
        <div className="flex items-center gap-1 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={handleCopy} className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors" title="Copy">
            {copied ? <Check size={15} className="text-[#10a37f]" /> : <Copy size={15} />}
          </button>
          <button
            onClick={() => setLiked(true)}
            className={`p-1.5 rounded-lg hover:bg-white/8 transition-colors ${liked === true ? "text-[#10a37f]" : "text-[#8e8ea0] hover:text-[#ececec]"}`}
            title="Good response"
          >
            <ThumbsUp size={15} />
          </button>
          <button
            onClick={() => setLiked(false)}
            className={`p-1.5 rounded-lg hover:bg-white/8 transition-colors ${liked === false ? "text-red-400" : "text-[#8e8ea0] hover:text-[#ececec]"}`}
            title="Bad response"
          >
            <ThumbsDown size={15} />
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors" title="Regenerate">
            <RefreshCw size={15} />
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors" title="More options">
            <MoreHorizontal size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ onSuggest }: { onSuggest: (text: string) => void }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 pb-8">
      <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center mb-6 shadow-lg">
        <svg width="28" height="28" viewBox="0 0 41 41" fill="none">
          <path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.313-2.635 10.079 10.079 0 0 0-9.614 6.977 9.967 9.967 0 0 0-6.664 4.834 10.08 10.08 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.313 2.634 10.079 10.079 0 0 0 9.614-6.976 9.967 9.967 0 0 0 6.664-4.834 10.079 10.079 0 0 0-1.24-11.818zM22.498 37.886a7.474 7.474 0 0 1-4.799-1.735c.061-.033.168-.091.237-.134l7.964-4.6a1.294 1.294 0 0 0 .655-1.134V19.054l3.366 1.944a.12.12 0 0 1 .066.092v9.299a7.505 7.505 0 0 1-7.49 7.496zM6.392 31.006a7.471 7.471 0 0 1-.894-5.023c.06.036.162.099.237.141l7.964 4.6a1.297 1.297 0 0 0 1.308 0l9.724-5.614v3.888a.12.12 0 0 1-.048.103l-8.051 4.649a7.504 7.504 0 0 1-10.24-2.744zM4.297 13.62A7.469 7.469 0 0 1 8.2 10.333c0 .068-.004.19-.004.274v9.201a1.294 1.294 0 0 0 .654 1.132l9.723 5.614-3.366 1.944a.12.12 0 0 1-.114.012L7.044 23.86a7.504 7.504 0 0 1-2.747-10.24zm27.658 6.437l-9.724-5.615 3.367-1.943a.121.121 0 0 1 .114-.012l8.048 4.648a7.498 7.498 0 0 1-1.158 13.528v-9.476a1.293 1.293 0 0 0-.647-1.13zm3.35-5.043c-.059-.037-.162-.099-.236-.141l-7.965-4.6a1.298 1.298 0 0 0-1.308 0l-9.723 5.614v-3.888a.12.12 0 0 1 .048-.103l8.05-4.645a7.497 7.497 0 0 1 11.135 7.763zm-21.063 6.929l-3.367-1.944a.12.12 0 0 1-.065-.092v-9.299a7.497 7.497 0 0 1 12.293-5.756 6.94 6.94 0 0 0-.236.134l-7.965 4.6a1.294 1.294 0 0 0-.654 1.132l-.006 11.225zm1.829-3.943l4.33-2.501 4.332 2.5v4.999l-4.331 2.5-4.331-2.5V18z" fill="#000" />
        </svg>
      </div>
      <h1 className="text-3xl font-semibold text-[#ececec] mb-8">What can I help with?</h1>
      <div className="grid grid-cols-2 gap-2.5 w-full max-w-xl mb-8">
        {SUGGESTIONS.map((s) => (
          <button
            key={s.label}
            onClick={() => onSuggest(s.text)}
            className="flex items-start gap-3 p-4 rounded-2xl bg-[#2f2f2f] hover:bg-[#3a3a3a] border border-white/8 transition-colors text-left group"
          >
            <s.icon size={18} className="text-[#8e8ea0] group-hover:text-[#ececec] transition-colors mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-[#ececec]">{s.label}</p>
              <p className="text-xs text-[#8e8ea0] mt-0.5 leading-relaxed">{s.text}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function SettingsModal({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<SettingsTab>("general");
  const [theme, setTheme] = useState<"dark" | "light" | "system">("dark");

  const tabs: { id: SettingsTab; label: string; icon: React.ElementType }[] = [
    { id: "general", label: "General", icon: Settings },
    { id: "account", label: "Account", icon: User },
    { id: "security", label: "Security", icon: Shield },
    { id: "data", label: "Data controls", icon: Globe },
    { id: "billing", label: "Billing", icon: CreditCard },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#2f2f2f] rounded-2xl shadow-2xl border border-white/10 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/8">
          <h2 className="text-lg font-semibold text-[#ececec]">Settings</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors">
            <X size={18} />
          </button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar tabs */}
          <div className="w-48 border-r border-white/8 p-3 flex-shrink-0">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors text-left mb-0.5 ${
                  tab === t.id
                    ? "bg-white/10 text-[#ececec] font-medium"
                    : "text-[#8e8ea0] hover:text-[#ececec] hover:bg-white/6"
                }`}
              >
                <t.icon size={16} />
                {t.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {tab === "general" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-semibold text-[#ececec] mb-4">Appearance</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[#ececec]">Theme</p>
                      <p className="text-xs text-[#8e8ea0] mt-0.5">Choose your preferred interface theme</p>
                    </div>
                    <div className="flex bg-[#171717] rounded-lg p-1 gap-1">
                      {(["light", "dark", "system"] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => setTheme(t)}
                          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors capitalize ${
                            theme === t ? "bg-[#2f2f2f] text-[#ececec]" : "text-[#8e8ea0] hover:text-[#ececec]"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="border-t border-white/8 pt-6">
                  <h3 className="text-sm font-semibold text-[#ececec] mb-4">Language & Region</h3>
                  <SettingsRow label="Language" description="Interface language">
                    <select className="bg-[#171717] text-sm text-[#ececec] border border-white/10 rounded-lg px-3 py-1.5 outline-none">
                      <option>English (US)</option>
                      <option>Español</option>
                      <option>Français</option>
                      <option>Deutsch</option>
                    </select>
                  </SettingsRow>
                </div>
                <div className="border-t border-white/8 pt-6">
                  <h3 className="text-sm font-semibold text-[#ececec] mb-4">Chat</h3>
                  <SettingsRow label="Always show code when using data analyst" description="Show the underlying code for responses generated with code">
                    <Toggle defaultChecked />
                  </SettingsRow>
                  <SettingsRow label="Show follow-up suggestions" description="Display suggested follow-up prompts after responses">
                    <Toggle defaultChecked />
                  </SettingsRow>
                </div>
              </div>
            )}

            {tab === "account" && (
              <div className="space-y-6">
                <div className="flex items-center gap-4 pb-6 border-b border-white/8">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#10a37f] to-[#0d8f6e] flex items-center justify-center text-white text-2xl font-semibold">
                    A
                  </div>
                  <div>
                    <p className="text-base font-semibold text-[#ececec]">Alex Johnson</p>
                    <p className="text-sm text-[#8e8ea0]">alex.johnson@example.com</p>
                    <span className="inline-flex items-center gap-1 text-xs bg-[#10a37f]/15 text-[#10a37f] px-2 py-0.5 rounded-full mt-1">
                      <Zap size={11} /> Free plan
                    </span>
                  </div>
                </div>
                <SettingsRow label="Display name" description="How your name appears in conversations">
                  <input defaultValue="Alex Johnson" className="bg-[#171717] text-sm text-[#ececec] border border-white/10 rounded-lg px-3 py-1.5 outline-none w-40 focus:border-[#10a37f]/50 transition-colors" />
                </SettingsRow>
                <div className="pt-4 border-t border-white/8">
                  <button className="flex items-center gap-2 px-4 py-2 bg-[#10a37f] hover:bg-[#0d8f6e] text-white rounded-lg text-sm font-medium transition-colors">
                    <Zap size={15} />
                    Upgrade to ChatGPT Plus
                  </button>
                </div>
              </div>
            )}

            {tab === "security" && (
              <div className="space-y-6">
                <h3 className="text-sm font-semibold text-[#ececec] mb-4">Security</h3>
                <SettingsRow label="Two-factor authentication" description="Add an extra layer of security to your account">
                  <Toggle />
                </SettingsRow>
                <SettingsRow label="Login notifications" description="Get notified when a new device signs in">
                  <Toggle defaultChecked />
                </SettingsRow>
                <div className="pt-4 border-t border-white/8">
                  <button className="text-sm text-[#8e8ea0] hover:text-[#ececec] transition-colors">
                    Manage active sessions →
                  </button>
                </div>
              </div>
            )}

            {tab === "data" && (
              <div className="space-y-6">
                <h3 className="text-sm font-semibold text-[#ececec] mb-4">Data controls</h3>
                <SettingsRow label="Improve the model for everyone" description="Allow your conversations to be used to train our models">
                  <Toggle defaultChecked />
                </SettingsRow>
                <SettingsRow label="Shared links" description="Manage who can view your shared conversations">
                  <Toggle defaultChecked />
                </SettingsRow>
                <div className="pt-4 border-t border-white/8 space-y-3">
                  <button className="w-full text-left px-4 py-3 rounded-xl border border-white/10 hover:border-white/20 transition-colors">
                    <p className="text-sm font-medium text-[#ececec]">Export data</p>
                    <p className="text-xs text-[#8e8ea0] mt-0.5">Download all your conversations and data</p>
                  </button>
                  <button className="w-full text-left px-4 py-3 rounded-xl border border-red-500/20 hover:border-red-500/40 transition-colors">
                    <p className="text-sm font-medium text-red-400">Delete account</p>
                    <p className="text-xs text-[#8e8ea0] mt-0.5">Permanently delete your account and all data</p>
                  </button>
                </div>
              </div>
            )}

            {tab === "billing" && (
              <div className="space-y-6">
                <div className="p-4 rounded-xl bg-gradient-to-br from-[#10a37f]/15 to-[#10a37f]/5 border border-[#10a37f]/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-[#ececec]">Free Plan</p>
                      <p className="text-xs text-[#8e8ea0] mt-0.5">Limited to GPT-4o mini with standard limits</p>
                    </div>
                    <button className="px-3 py-1.5 bg-[#10a37f] hover:bg-[#0d8f6e] text-white rounded-lg text-xs font-medium transition-colors">
                      Upgrade
                    </button>
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { plan: "ChatGPT Plus", price: "$20/mo", features: ["GPT-4o access", "Advanced reasoning", "Image generation", "Higher limits"] },
                    { plan: "ChatGPT Team", price: "$25/mo", features: ["Everything in Plus", "Team workspace", "Admin controls", "Priority support"] },
                  ].map((p) => (
                    <div key={p.plan} className="p-4 rounded-xl border border-white/10 hover:border-white/20 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm font-semibold text-[#ececec]">{p.plan}</p>
                        <p className="text-sm text-[#8e8ea0]">{p.price}</p>
                      </div>
                      <ul className="space-y-1.5">
                        {p.features.map((f) => (
                          <li key={f} className="flex items-center gap-2 text-xs text-[#8e8ea0]">
                            <Check size={12} className="text-[#10a37f]" />
                            {f}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Toggle({ defaultChecked = false }: { defaultChecked?: boolean }) {
  const [on, setOn] = useState(defaultChecked);
  return (
    <button
      onClick={() => setOn(!on)}
      className={`relative inline-flex w-10 h-5.5 rounded-full transition-colors duration-200 ${on ? "bg-[#10a37f]" : "bg-white/20"}`}
      style={{ height: "22px", width: "40px" }}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-4.5 h-4.5 bg-white rounded-full shadow-sm transition-transform duration-200 ${on ? "translate-x-[18px]" : "translate-x-0"}`}
        style={{ width: "18px", height: "18px" }}
      />
    </button>
  );
}

function SettingsRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-white/6 last:border-0">
      <div className="flex-1 mr-4">
        <p className="text-sm text-[#ececec] font-medium">{label}</p>
        <p className="text-xs text-[#8e8ea0] mt-0.5 leading-relaxed">{description}</p>
      </div>
      {children}
    </div>
  );
}

function ExploreView({ onBack }: { onBack: () => void }) {
  const categories = ["All", "Writing", "Productivity", "Research", "Coding", "Education", "Lifestyle"];
  const [activeCategory, setActiveCategory] = useState("All");

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="border-b border-white/8 px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors">
          <ChevronRight size={18} className="rotate-180" />
        </button>
        <h2 className="text-base font-semibold text-[#ececec]">Explore GPTs</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6">
        {/* Search */}
        <div className="flex items-center gap-2 px-4 py-3 bg-[#2f2f2f] rounded-xl border border-white/10 mb-6 max-w-md">
          <Search size={16} className="text-[#8e8ea0]" />
          <input placeholder="Search GPTs" className="bg-transparent text-sm text-[#ececec] placeholder-[#8e8ea0] outline-none flex-1" />
        </div>

        {/* Category pills */}
        <div className="flex gap-2 flex-wrap mb-6">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                activeCategory === c
                  ? "bg-white text-black"
                  : "bg-[#2f2f2f] text-[#8e8ea0] hover:text-[#ececec] border border-white/10"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Featured */}
        <h3 className="text-xs font-semibold text-[#8e8ea0] uppercase tracking-wider mb-3">Featured</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
          {GPT_STORE_ITEMS.slice(0, 4).map((item) => (
            <button
              key={item.name}
              className="flex items-center gap-4 p-4 bg-[#2f2f2f] rounded-2xl border border-white/8 hover:border-white/20 transition-all text-left group"
            >
              <div className="w-12 h-12 rounded-xl bg-[#171717] border border-white/10 flex items-center justify-center text-2xl flex-shrink-0">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#ececec] group-hover:text-white transition-colors">{item.name}</p>
                <p className="text-xs text-[#8e8ea0] mt-0.5 leading-relaxed">{item.desc}</p>
                <span className="text-xs text-[#8e8ea0] mt-1 inline-block">{item.category}</span>
              </div>
            </button>
          ))}
        </div>

        <h3 className="text-xs font-semibold text-[#8e8ea0] uppercase tracking-wider mb-3">Popular</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {GPT_STORE_ITEMS.slice(4).map((item) => (
            <button
              key={item.name}
              className="flex items-center gap-4 p-4 bg-[#2f2f2f] rounded-2xl border border-white/8 hover:border-white/20 transition-all text-left group"
            >
              <div className="w-12 h-12 rounded-xl bg-[#171717] border border-white/10 flex items-center justify-center text-2xl flex-shrink-0">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#ececec] group-hover:text-white transition-colors">{item.name}</p>
                <p className="text-xs text-[#8e8ea0] mt-0.5 leading-relaxed">{item.desc}</p>
                <span className="text-xs text-[#8e8ea0] mt-1 inline-block">{item.category}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(SAMPLE_CONVERSATIONS);
  const [activeConvoId, setActiveConvoId] = useState<string | null>(null);
  const [model, setModel] = useState("gpt-4o");
  const [view, setView] = useState<View>("chat");
  const [showSettings, setShowSettings] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConvo = conversations.find((c) => c.id === activeConvoId) ?? null;

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [activeConvo?.messages.length, streaming]);

  const handleNewChat = () => {
    setActiveConvoId(null);
    setView("chat");
  };

  const handleSelectConvo = (id: string) => {
    setActiveConvoId(id);
    setView("chat");
  };

  const handleSend = (text: string) => {
    const userMsg: Message = {
      id: Math.random().toString(36).slice(2),
      role: "user",
      content: text,
      timestamp: new Date(),
    };

    if (!activeConvoId) {
      const newConvo: Conversation = {
        id: Math.random().toString(36).slice(2),
        title: text.slice(0, 50) + (text.length > 50 ? "..." : ""),
        preview: text,
        timestamp: new Date(),
        messages: [userMsg],
      };
      setConversations((prev) => [newConvo, ...prev]);
      setActiveConvoId(newConvo.id);

      // Simulate streaming response
      setStreaming(true);
      setTimeout(() => {
        const assistantMsg: Message = {
          id: Math.random().toString(36).slice(2),
          role: "assistant",
          content: getSimulatedResponse(text),
          timestamp: new Date(),
        };
        setConversations((prev) =>
          prev.map((c) =>
            c.id === newConvo.id ? { ...c, messages: [...c.messages, assistantMsg] } : c
          )
        );
        setStreaming(false);
      }, 1500);
    } else {
      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeConvoId ? { ...c, messages: [...c.messages, userMsg] } : c
        )
      );

      setStreaming(true);
      setTimeout(() => {
        const assistantMsg: Message = {
          id: Math.random().toString(36).slice(2),
          role: "assistant",
          content: getSimulatedResponse(text),
          timestamp: new Date(),
        };
        setConversations((prev) =>
          prev.map((c) =>
            c.id === activeConvoId ? { ...c, messages: [...c.messages, assistantMsg] } : c
          )
        );
        setStreaming(false);
      }, 1500);
    }
  };

  return (
    <div className="flex h-screen bg-[#212121] font-[Inter,sans-serif] overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        conversations={conversations}
        activeId={activeConvoId}
        onSelect={handleSelectConvo}
        onNew={handleNewChat}
        onSettings={() => setShowSettings(true)}
        onExplore={() => setView("explore")}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {view === "explore" ? (
          <ExploreView onBack={() => setView("chat")} />
        ) : (
          <>
            {/* Top bar */}
            <header className="flex items-center justify-between px-4 py-3 flex-shrink-0">
              <div className="flex items-center gap-2">
                {sidebarCollapsed && (
                  <>
                    <button
                      onClick={() => setSidebarCollapsed(false)}
                      className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors"
                    >
                      <Menu size={18} />
                    </button>
                    <button
                      onClick={handleNewChat}
                      className="p-2 rounded-lg hover:bg-white/8 text-[#8e8ea0] hover:text-[#ececec] transition-colors"
                    >
                      <Edit3 size={18} />
                    </button>
                  </>
                )}
              </div>
              <ModelSelector model={model} onChange={setModel} />
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2f2f2f] hover:bg-[#3a3a3a] border border-white/10 text-[#ececec] text-sm font-medium transition-colors">
                  <Share2 size={14} />
                  Share
                </button>
              </div>
            </header>

            {/* Chat area */}
            <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
              {!activeConvo || activeConvo.messages.length === 0 ? (
                <EmptyState onSuggest={handleSend} />
              ) : (
                <div className="max-w-3xl mx-auto px-4 pt-6 pb-4">
                  {activeConvo.messages.map((msg) => (
                    <MessageBubble key={msg.id} message={msg} />
                  ))}
                  {streaming && <StreamingIndicator />}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* Input */}
            <div className="px-4 pb-5 pt-2 flex-shrink-0">
              <ChatInput onSend={handleSend} disabled={streaming} />
            </div>
          </>
        )}
      </div>

      {/* Settings modal */}
      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} />}
    </div>
  );
}

function StreamingIndicator() {
  return (
    <div className="flex gap-3 mb-6">
      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 mt-0.5">
        <svg width="18" height="18" viewBox="0 0 41 41" fill="none">
          <path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.313-2.635 10.079 10.079 0 0 0-9.614 6.977 9.967 9.967 0 0 0-6.664 4.834 10.08 10.08 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.313 2.634 10.079 10.079 0 0 0 9.614-6.976 9.967 9.967 0 0 0 6.664-4.834 10.079 10.079 0 0 0-1.24-11.818zM22.498 37.886a7.474 7.474 0 0 1-4.799-1.735c.061-.033.168-.091.237-.134l7.964-4.6a1.294 1.294 0 0 0 .655-1.134V19.054l3.366 1.944a.12.12 0 0 1 .066.092v9.299a7.505 7.505 0 0 1-7.49 7.496zM6.392 31.006a7.471 7.471 0 0 1-.894-5.023c.06.036.162.099.237.141l7.964 4.6a1.297 1.297 0 0 0 1.308 0l9.724-5.614v3.888a.12.12 0 0 1-.048.103l-8.051 4.649a7.504 7.504 0 0 1-10.24-2.744zM4.297 13.62A7.469 7.469 0 0 1 8.2 10.333c0 .068-.004.19-.004.274v9.201a1.294 1.294 0 0 0 .654 1.132l9.723 5.614-3.366 1.944a.12.12 0 0 1-.114.012L7.044 23.86a7.504 7.504 0 0 1-2.747-10.24zm27.658 6.437l-9.724-5.615 3.367-1.943a.121.121 0 0 1 .114-.012l8.048 4.648a7.498 7.498 0 0 1-1.158 13.528v-9.476a1.293 1.293 0 0 0-.647-1.13zm3.35-5.043c-.059-.037-.162-.099-.236-.141l-7.965-4.6a1.298 1.298 0 0 0-1.308 0l-9.723 5.614v-3.888a.12.12 0 0 1 .048-.103l8.05-4.645a7.497 7.497 0 0 1 11.135 7.763zm-21.063 6.929l-3.367-1.944a.12.12 0 0 1-.065-.092v-9.299a7.497 7.497 0 0 1 12.293-5.756 6.94 6.94 0 0 0-.236.134l-7.965 4.6a1.294 1.294 0 0 0-.654 1.132l-.006 11.225zm1.829-3.943l4.33-2.501 4.332 2.5v4.999l-4.331 2.5-4.331-2.5V18z" fill="#000" />
        </svg>
      </div>
      <div className="flex items-center gap-1.5 pt-2">
        <span className="w-2 h-2 rounded-full bg-[#8e8ea0] animate-bounce" style={{ animationDelay: "0ms" }} />
        <span className="w-2 h-2 rounded-full bg-[#8e8ea0] animate-bounce" style={{ animationDelay: "150ms" }} />
        <span className="w-2 h-2 rounded-full bg-[#8e8ea0] animate-bounce" style={{ animationDelay: "300ms" }} />
      </div>
    </div>
  );
}

function getSimulatedResponse(input: string): string {
  const lower = input.toLowerCase();
  if (lower.includes("code") || lower.includes("function") || lower.includes("script")) {
    return `Here's a clean implementation for your request:

\`\`\`typescript
function processData(input: string[]): Record<string, number> {
  return input.reduce((acc, item) => {
    acc[item] = (acc[item] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);
}

// Example usage
const result = processData(["apple", "banana", "apple", "cherry"]);
console.log(result); // { apple: 2, banana: 1, cherry: 1 }
\`\`\`

**Key points:**
- Uses \`reduce\` for a single-pass O(n) solution
- Handles duplicate keys automatically
- Fully typed with TypeScript generics

Let me know if you'd like to extend this further.`;
  }

  if (lower.includes("help") || lower.includes("what can")) {
    return `I can help you with a wide range of tasks:

**Writing & Communication**
Draft emails, essays, reports, cover letters, and creative content.

**Code & Development**
Write, debug, and explain code in Python, JavaScript, TypeScript, Go, Rust, and more.

**Research & Analysis**
Summarize documents, compare ideas, explain complex topics, and analyze data.

**Problem Solving**
Work through math problems, logic puzzles, and strategic decisions.

**Creative Projects**
Generate ideas, write stories, compose poems, brainstorm concepts.

What would you like to start with?`;
  }

  return `That's a great question. Let me give you a thorough answer.

**Overview**

${input} is something I can definitely help with. Here's what you need to know:

The key insight is that approaching this systematically leads to better outcomes. Breaking it into smaller parts makes it more manageable and ensures you don't miss any important details.

**Recommendations**

1. Start by clearly defining your goal and success criteria
2. Gather the relevant context and constraints upfront
3. Work iteratively — test early, adjust often
4. Document your decisions as you go

Is there a specific aspect you'd like me to go deeper on?`;
}
