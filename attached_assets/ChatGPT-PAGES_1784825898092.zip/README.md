
  # ChatGPT-PAGES

  This is a code bundle for ChatGPT-PAGES. The original project is available at https://www.figma.com/design/ggPAmnEL7Zz5IfVy2eMDqI/ChatGPT-PAGES.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  